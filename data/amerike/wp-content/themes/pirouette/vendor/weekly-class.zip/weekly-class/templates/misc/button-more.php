<script type="text/x-template" id="wcs_templates_misc--button-more">
	<button v-on:click="addEvents" class="ladda-button wcs-more wcs-btn--action" :data-spinner-color="color" data-style="expand-right" data-size="xs">
		<span class="ladda-label">{{more}}</span>
	</button>
</script>
